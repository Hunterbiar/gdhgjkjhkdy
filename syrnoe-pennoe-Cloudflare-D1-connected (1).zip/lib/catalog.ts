import seed from '../app/menu.json';

export type MenuVariant = {label:string;price:number|null};
export type Dish = {id:string;name:string;category:string;description:string;image:string;variants:MenuVariant[];visible:boolean};
export type Category = {name:string;visible:boolean};
export type Catalog = {categories:Category[];menu:Dish[]};

export const initialCatalog: Catalog = {
 categories:['Пицца','Закуски','Сеты','Десерты'].map(name=>({name,visible:true})),
 menu:seed as Dish[],
};

const validStr=(v:unknown,max:number)=>typeof v==='string'&&v.trim().length>0&&v.length<=max;
export function validCatalog(value:unknown):value is Catalog {
 if(!value||typeof value!=='object')return false;
 const {categories,menu}=value as Catalog;
 if(!Array.isArray(categories)||categories.length>30||!categories.length||!Array.isArray(menu)||menu.length>500)return false;
 if(categories.some(c=>!c||!validStr(c.name,70)||typeof c.visible!=='boolean'))return false;
 const names=categories.map(c=>c.name);
 if(new Set(names).size!==names.length)return false;
 if(menu.some(p=>!p||!validStr(p.id,120)||!validStr(p.name,120)||!names.includes(p.category)||typeof p.description!=='string'||p.description.length>1500||typeof p.image!=='string'||p.image.length>600||!(p.image.startsWith('/assets/')||p.image.startsWith('/photos/')||/^\/api\/images\/[a-z0-9-]+$/i.test(p.image))||typeof p.visible!=='boolean'||!Array.isArray(p.variants)||p.variants.length===0||p.variants.length>12||p.variants.some(v=>!v||!validStr(v.label,80)||!(v.price===null||(Number.isInteger(v.price)&&v.price>=0&&v.price<=1000000)))))return false;
 return new Set(menu.map(p=>p.id)).size===menu.length;
}
