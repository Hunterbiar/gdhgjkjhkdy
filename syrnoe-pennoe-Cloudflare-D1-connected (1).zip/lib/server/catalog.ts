import {env} from 'cloudflare:workers';
import {initialCatalog,validCatalog,type Catalog,type Dish} from '../catalog';

export async function readCatalog():Promise<Catalog>{
 if(!env.DB)return initialCatalog;
 const row=await env.DB.prepare("SELECT key,value FROM settings WHERE key IN ('catalog','menu') ORDER BY CASE WHEN key='catalog' THEN 0 ELSE 1 END LIMIT 1").first<{key:string;value:string}>();
 if(!row)return initialCatalog;
 try{
  const data=JSON.parse(row.value);
  if(row.key==='catalog'&&validCatalog(data))return data;
  if(row.key==='menu'&&Array.isArray(data)){
   const existing=new Set(data.map((p:Dish)=>p.category));
   const base=initialCatalog.categories.map(c=>({...c}));
   for(const name of existing)if(typeof name==='string'&&!base.some(c=>c.name===name))base.push({name,visible:true});
   const migrated={categories:base,menu:data};
   if(validCatalog(migrated))return migrated;
  }
 }catch{/* fallback to shipped data */}
 return initialCatalog;
}
export async function saveCatalog(data:Catalog){
 if(!env.DB)throw new Error('D1 storage is unavailable');
 await env.DB.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind('catalog',JSON.stringify(data)).run();
}
