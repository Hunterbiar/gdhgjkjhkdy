import {env} from 'cloudflare:workers';
const COOKIE='sp_admin';
const encoder=new TextEncoder();
const toHex=(b:ArrayBuffer)=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');
const eq=(a:string,b:string)=>{if(a.length!==b.length)return false;let n=0;for(let i=0;i<a.length;i++)n|=a.charCodeAt(i)^b.charCodeAt(i);return n===0};
function settings(){const vars=env as typeof env & {ADMIN_PASSWORD_HASH?:string;ADMIN_SESSION_SECRET?:string};return {hash:vars.ADMIN_PASSWORD_HASH,secret:vars.ADMIN_SESSION_SECRET}}
export function adminConfigured(){const s=settings();return Boolean(s.hash&&s.secret&&s.secret.length>=32)}
async function sign(data:string){const secret=settings().secret;if(!secret)throw new Error('Admin secret missing');const key=await crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return toHex(await crypto.subtle.sign('HMAC',key,encoder.encode(data)))}
export async function checkPassword(password:string){
 const stored=settings().hash;if(!stored||!password||password.length>256)return false;
 const [alg,iter,salt,hash]=stored.split('$');const count=Number(iter);
 if(alg!=='pbkdf2'||!Number.isSafeInteger(count)||count<100000||count>1000000||!salt||!hash)return false;
 const key=await crypto.subtle.importKey('raw',encoder.encode(password),'PBKDF2',false,['deriveBits']);
 const result=await crypto.subtle.deriveBits({name:'PBKDF2',salt:encoder.encode(salt),iterations:count,hash:'SHA-256'},key,256);
 return eq(toHex(result),hash);
}
export async function createAdminCookie(req:Request){const expiration=Date.now()+12*60*60*1000;const token=expiration+'.'+crypto.randomUUID();const signature=await sign(token);const secure=new URL(req.url).protocol==='https:'?'; Secure':'';return `${COOKIE}=${token}.${signature}; Path=/; HttpOnly; SameSite=Strict; Max-Age=43200${secure}`}
export function expiredAdminCookie(){return `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`}
export async function isAdmin(req:Request){if(!adminConfigured())return false;const header=req.headers.get('cookie')||'';const match=header.match(/(?:^|;\s*)sp_admin=([^;]+)/);if(!match)return false;const val=match[1];const parts=val.split('.');if(parts.length!==3)return false;const [expiration,nonce,signature]=parts;const t=Number(expiration);if(!Number.isSafeInteger(t)||t<Date.now()||t>Date.now()+12*60*60*1000||!/^[0-9a-f-]{36}$/.test(nonce)||!/^[a-f0-9]{64}$/.test(signature))return false;return eq(signature,await sign(`${expiration}.${nonce}`));}
export function sameOrigin(req:Request){return req.headers.get('origin')===new URL(req.url).origin}
export async function adminOnly(req:Request){if(!sameOrigin(req))return new Response('Forbidden origin',{status:403});if(!await isAdmin(req))return new Response('Требуется вход в админку',{status:401});return null}
