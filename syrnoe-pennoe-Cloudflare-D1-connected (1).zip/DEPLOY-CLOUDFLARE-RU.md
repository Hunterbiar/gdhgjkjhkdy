# Сырное Пенное — Cloudflare Workers (без PHP)

Это адаптация предыдущего премиального сайта для **Cloudflare Workers**, с исходными иллюстрациями, меню из 55 блюд, анимациями и админкой. Эта папка содержит **исходный код**, не статический набор HTML. Проект нужно **собрать и опубликовать** (через GitHub/Cloudflare Builds или локально с Wrangler).

> Проверка: файлы и конфигурации собраны, но полноценная сборка `pnpm build` и публикация в Cloudflare в текущей среде не выполнялись из-за недоступности npm и отсутствия доступа к вашему аккаунту. После установки необходимо проверить работу проекта в браузере.

## 1. Зарегистрируйтесь в Cloudflare

Зайдите на https://dash.cloudflare.com/ . Домен в REG.RU пока **не перенастраивайте**: сначала протестируем временный `*.workers.dev`.

## 2. Создайте D1 и R2 в Cloudflare

- Workers & Pages → D1 SQL Database (или меню Storage & databases → D1) → Create database → имя `syrnoe-pennoe-db`.
- Откройте эту базу → Console → выполните один раз SQL:

```sql
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL
);
```

- Создайте бакет R2 `syrnoe-pennoe-media` (Storage & databases → R2 → Create bucket). Возможно потребуется активация R2 и платёжный метод.
- UUID вашей базы D1 уже внесён в `wrangler.jsonc`. Имена привязок оставьте **строго** `DB` и `BUCKET`. Проверьте, что бакет R2 действительно называется `syrnoe-pennoe-media`.

## 3. Загрузите исходники в GitHub

Создайте пустой репозиторий на https://github.com/new . Загрузите **содержимое** этой папки (не архив ZIP как единственный файл и не вложенную папку) в корень репозитория, включая `package.json`, `vite.config.ts`, `wrangler.jsonc`, `app/`, `public/`, `pnpm-lock.yaml`.

Удобнее через `git` на ПК, так как GitHub web upload не всегда принимает папки целиком. Если GitHub уже подключён к Cloudflare, можно использовать и его.

## 4. Свяжите GitHub c Cloudflare Workers

Cloudflare → Workers & Pages → Create application → GitHub → выберите созданный репозиторий, Worker name `syrnoe-pennoe`.

Build settings:

- **Root directory**: `/` (корень репозитория).
- **Build command**: `pnpm run build`.
- **Deploy command**: `pnpm exec wrangler deploy --config dist/server/wrangler.json`.
- **Build environment variables**: `NODE_VERSION=22`, `PNPM_VERSION=11.25.0`.

Cloudflare может автоматически установить зависимости на основе `pnpm-lock.yaml`. Если не сможет, используйте build command: `corepack enable && pnpm install --frozen-lockfile && pnpm run build`, при необходимости поставив build variable `SKIP_DEPENDENCY_INSTALL=1`.

**ВАЖНО:** в созданном Worker привязки должны совпадать с `wrangler.jsonc`: база D1 → `DB`, бакет R2 → `BUCKET`. Сборка должна успешно выполниться, прежде чем сайт откроется на `https://syrnoe-pennoe.<ваш-поддомен>.workers.dev`.

## 5. Включите админку безопасно

Создайте хеш пароля на своём компьютере с Node.js:

```bash
node tools/create-admin-hash.mjs "ВАШ-СЛОЖНЫЙ-ПАРОЛЬ-НЕ-КОРОЧЕ-12-СИМВОЛОВ"
```

Команда напечатает две переменные `ADMIN_PASSWORD_HASH` и `ADMIN_SESSION_SECRET`. В Cloudflare у Worker откройте **Settings → Variables and Secrets** и добавьте их **как Secret**, отдельно. Не пишите пароль или эти секреты в GitHub, `wrangler.jsonc` или клиентский код. После сохранения секретов при необходимости выполните повторный Deploy. Проверьте `https://...workers.dev/admin`.

При отсутствии D1 и её таблицы админка может выдавать ошибки даже при правильно заданных секретах.

## 6. Подключите домен REG.RU (после успешной проверки)

1. В Cloudflare → Add domain (или Websites → Add domain), введите ваш домен, выберите доступный тариф, например Free.
2. **Проверьте все DNS-записи**. Если используете почту на REG.RU, сохраните MX, SPF, DKIM, DMARC и нужные поддомены. Не удаляйте почтовые записи.
3. Cloudflare покажет **две конкретные NS-записи**. В REG.RU → Домены → ваш домен → DNS-серверы → замените текущие NS на выданные Cloudflare. Не используйте универсальные/выдуманные NS. При включённом DNSSEC предварительно проверьте DS-записи.
4. Дождитесь статуса Active в Cloudflare.
5. Workers & Pages → ваш Worker → Settings → Domains & Routes → Add → **Custom Domain** → `example.ru`. При необходимости аналогично `www.example.ru` и редирект между ними. Cloudflare автоматически создаёт нужные DNS-записи и сертификат.

> Если домен уже обслуживает публичный сайт, переключение на новый может вызвать недоступность старой версии. Сначала проверьте Workers.dev. Чтобы не ломать почту, сверяйте записи до смены NS.

## Проверка работы

- Главная, кнопки меню, пиццы и десерты, календарь, мобильная версия, анимации;
- `/api/catalog`: возвращает данные; `/admin`: позволяет войти с заданным паролем;
- Измените цену и сохраните, откройте сайт в другом браузере — изменение должно сохраниться;
- Загрузите картинку через админку, проверьте, что она доступна по `/api/images/...`;
- Неавторизованные изменения каталога должны отклоняться.

## Локальный способ без GitHub (если установлен Node.js)

```bash
corepack enable
pnpm install --frozen-lockfile
pnpm exec wrangler login
pnpm run build
pnpm run deploy
```

D1 и R2 должны быть созданы, а UUID D1 вставлен в `wrangler.jsonc` ещё до сборки/деплоя. Если команда публикации в вашей версии Cloudflare Vite plugin выводит иной путь к конфигурации, проверьте путь к созданному `dist/**/wrangler.json` в логах сборки.

Официальные инструкции:
- https://developers.cloudflare.com/workers/ci-cd/builds/
- https://developers.cloudflare.com/workers/vite-plugin/
- https://developers.cloudflare.com/workers/configuration/routing/custom-domains/
- https://developers.cloudflare.com/dns/nameservers/update-nameservers/
