import {pbkdf2Sync,randomBytes} from 'node:crypto';
const password=process.argv[2];
if(!password||password.length<12){console.error('Использование: node tools/create-admin-hash.mjs "сложный-пароль-длиной-от-12-символов"');process.exit(1)}
const salt=randomBytes(24).toString('hex');
console.log('ADMIN_PASSWORD_HASH=pbkdf2$310000$'+salt+'$'+pbkdf2Sync(password,salt,310000,32,'sha256').toString('hex'));
console.log('ADMIN_SESSION_SECRET='+randomBytes(40).toString('hex'));
