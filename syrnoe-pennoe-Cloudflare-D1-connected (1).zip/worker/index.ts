import handler from "vinext/server/fetch-handler";

/** Keep the existing Vinext request handler; no ChatGPT-only bindings. */
export default {
  fetch(request: Request, env: Cloudflare.Env, ctx: ExecutionContext) {
    return handler.fetch(request, env, ctx);
  },
};
