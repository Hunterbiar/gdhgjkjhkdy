// Kept for compatibility with existing installations. Both routes use the same persistent catalog.
import {readCatalog,saveCatalog} from '../../../lib/server/catalog';
import {validCatalog} from '../../../lib/catalog';
import {adminOnly} from '../../../lib/server/admin-auth';
export async function GET(){return Response.json((await readCatalog()).menu,{headers:{'Cache-Control':'no-store'}})}
export async function PUT(req:Request){const denied=await adminOnly(req);if(denied)return denied;let menu:unknown;try{menu=await req.json()}catch{return new Response('Bad JSON',{status:400})}const old=await readCatalog();const next={...old,menu};if(!validCatalog(next))return new Response('Invalid menu',{status:400});await saveCatalog(next);return Response.json({ok:true})}
