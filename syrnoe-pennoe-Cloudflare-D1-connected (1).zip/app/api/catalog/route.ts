import {validCatalog} from '../../../lib/catalog';
import {readCatalog,saveCatalog} from '../../../lib/server/catalog';
import {adminOnly} from '../../../lib/server/admin-auth';
export async function GET(){try{return Response.json(await readCatalog(),{headers:{'Cache-Control':'no-store'}})}catch{return new Response('Storage error',{status:503})}}
export async function PUT(req:Request){const denied=await adminOnly(req);if(denied)return denied;let data:unknown;try{data=await req.json()}catch{return new Response('Неверный JSON',{status:400})}if(!validCatalog(data))return new Response('Некорректные данные меню',{status:400});try{await saveCatalog(data);return Response.json({ok:true})}catch{return new Response('Ошибка сохранения D1',{status:503})}}
