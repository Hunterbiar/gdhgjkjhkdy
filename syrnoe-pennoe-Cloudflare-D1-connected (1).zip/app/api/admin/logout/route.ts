import {expiredAdminCookie,sameOrigin} from '../../../../lib/server/admin-auth';
export async function POST(req:Request){if(!sameOrigin(req))return new Response('Forbidden',{status:403});return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Set-Cookie':expiredAdminCookie(),'Cache-Control':'no-store'}})}
