import {adminConfigured,isAdmin} from '../../../../lib/server/admin-auth';
export async function GET(req:Request){return Response.json({authenticated:await isAdmin(req),configured:adminConfigured()},{headers:{'Cache-Control':'no-store'}})}
