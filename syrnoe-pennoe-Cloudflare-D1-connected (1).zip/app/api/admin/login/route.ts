import {adminConfigured,checkPassword,createAdminCookie,sameOrigin} from '../../../../lib/server/admin-auth';
import {env} from 'cloudflare:workers';
export async function POST(req:Request){
 if(!sameOrigin(req))return new Response('Запрос с другого сайта запрещён',{status:403});
 if(!adminConfigured())return new Response('Задайте ADMIN_PASSWORD_HASH и ADMIN_SESSION_SECRET на сервере',{status:503});
 const {password}=await req.json().catch(()=>({password:''}));
 if(typeof password!=='string')return new Response('Неверный запрос',{status:400});
 // Persistent, IP-scoped cooldown across Worker instances. Uses existing settings table.
 const ip=(req.headers.get('cf-connecting-ip')||'local').slice(0,80);
 const key='login-fails:'+toIPKey(ip);const row=await env.DB!.prepare('SELECT value FROM settings WHERE key=?').bind(key).first<{value:string}>();
 let record:{count:number;since:number}={count:0,since:Date.now()};
 if(row){try{record=JSON.parse(row.value)}catch{}}
 if(Date.now()-record.since>15*60*1000)record={count:0,since:Date.now()};
 if(record.count>=8)return new Response('Слишком много попыток. Попробуйте через 15 минут.',{status:429});
 if(!await checkPassword(password)){
  record.count++;
  await env.DB!.prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').bind(key,JSON.stringify(record)).run();
  return new Response('Неверный пароль',{status:401});
 }
 await env.DB!.prepare('DELETE FROM settings WHERE key=?').bind(key).run();
 return new Response(JSON.stringify({ok:true}),{headers:{'Content-Type':'application/json','Cache-Control':'no-store','Set-Cookie':await createAdminCookie(req)}});
}
function toIPKey(ip:string){let n=2166136261;for(let i=0;i<ip.length;i++)n=Math.imul(n^ip.charCodeAt(i),16777619);return (n>>>0).toString(16)}
