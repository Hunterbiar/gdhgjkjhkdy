import './globals.css';
export const metadata={title:'Сырное Пенное — пицца и свои люди',description:'Семейная пиццерия. Пицца, горячие закуски, сеты и десерты.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ru"><body>{children}</body></html>}
